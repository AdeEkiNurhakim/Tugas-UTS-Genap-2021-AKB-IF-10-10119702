// Tanggal Pengerjaan   :   05-06-2021
// NIM                  :   10119702
// Nama                 :   Ade Eki Nurhakim
// Kelas                :   IF10

package com.example.aplikasicatatanagenda;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.blogspot.ketikanmd.appcatatanagenda.R;

public class About extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        setTitle("About");
    }
}
