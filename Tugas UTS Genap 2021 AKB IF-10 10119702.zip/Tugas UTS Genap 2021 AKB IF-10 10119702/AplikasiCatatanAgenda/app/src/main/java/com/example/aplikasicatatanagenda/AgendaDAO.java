// Tanggal Pengerjaan   :   05-06-2021
// NIM                  :   10119702
// Nama                 :   Ade Eki Nurhakim
// Kelas                :   IF10

package com.example.aplikasicatatanagenda;

import android.database.Cursor;

public interface AgendaDAO {
    Cursor read();

    Cursor readpenting();

    boolean create(Agenda agenda);

    boolean update(Agenda agenda);

    boolean delete(int id);

}
