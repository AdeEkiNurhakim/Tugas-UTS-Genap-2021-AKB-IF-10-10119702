// Tanggal Pengerjaan   :   05-06-2021
// NIM                  :   10119702
// Nama                 :   Ade Eki Nurhakim
// Kelas                :   IF10

package com.example.aplikasicatatanagenda;

public class Agenda {
    private int id;
    private String nama;
    private String tanggal;
    private String tempat;
    private String keterangan;
    private String status;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getTanggal() {
        return tanggal;
    }

    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }

    public String getTempat() {
        return tempat;
    }

    public void setTempat(String tempat) {
        this.tempat = tempat;
    }

    public String getKeterangan() {
        return keterangan;
    }

    public void setKeterangan(String keterangan) {
        this.keterangan = keterangan;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }


}
