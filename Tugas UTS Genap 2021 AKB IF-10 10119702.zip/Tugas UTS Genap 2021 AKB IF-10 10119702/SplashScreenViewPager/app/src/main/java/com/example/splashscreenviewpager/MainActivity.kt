// Tanggal Pengerjaan   :   05-06-2021
// NIM                  :   10119702
// Nama                 :   Ade Eki Nurhakim
// Kelas                :   IF10

package com.example.splashscreenviewpager

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.jovanovic.stefan.mytestapp.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        supportActionBar?.hide()
    }
}